@extends('shared.base')

@section('content')
<h3>Página pública</h3>
@endsection