@extends('shared.base')

@section('content')
<h3>Página protegida</h3>
@endsection